import AmbientWave from '@/sections/AmbientWave'
import DhikrCounter from '@/sections/DhikrCounter'
import JourneyChart from '@/sections/JourneyChart'
import StatePanel from '@/sections/StatePanel'
import { useDhikrSession } from '@/hooks/useDhikrSession'

function Seal() {
  return (
    <svg width="64" height="64" viewBox="0 0 100 100" className="shrink-0">
      <defs>
        <path id="sealCircle" d="M50,50 m-38,0 a38,38 0 1,1 76,0 a38,38 0 1,1 -76,0" />
      </defs>
      <g className="seal-rotate">
        <text fontSize="10.5" fill="#af915f" style={{ fontFamily: 'Amiri, serif' }}>
          <textPath href="#sealCircle">
            سُبْحَانَ اللهِ وَبِحَمْدِهِ ۞ سُبْحَانَ اللهِ الْعَظِيمِ ۞
          </textPath>
        </text>
      </g>
      <circle cx="50" cy="50" r="3" fill="#d4b67e" />
      <circle cx="50" cy="50" r="27" fill="none" stroke="rgba(175,145,95,0.35)" strokeWidth="0.8" />
    </svg>
  )
}

export default function Home() {
  const s = useDhikrSession()

  return (
    <div className="relative min-h-screen">
      <AmbientWave getElapsed={s.getElapsed} pulse={s.pulse} />
      <div className="dot-grid pointer-events-none fixed inset-0" aria-hidden />

      <div className="relative mx-auto max-w-6xl px-5 pb-16 sm:px-8">
        {/* الترويسة */}
        <header className="flex items-center justify-between gap-6 py-8">
          <div className="flex items-center gap-5">
            <Seal />
            <div>
              <h1 className="font-display text-4xl text-[#fce1b6]">مِسبحة</h1>
              <p className="mt-1 text-sm text-[--ink-dim]">
                رحلة التسبيح عبر أمواج الدماغ — من بيتا إلى ألفا إلى ثيتا
              </p>
            </div>
          </div>
          <div className="hidden text-left text-[11px] leading-relaxed text-[--ink-faint] md:block">
            نموذج استرشادي تفاعلي
            <br />
            يرسم توقعاً لا قياساً
          </div>
        </header>

        <div className="hairline-b" />

        {/* المقطع الرئيسي */}
        <main className="grid gap-12 py-12 lg:grid-cols-2 lg:gap-10">
          <div className="fade-up">
            <DhikrCounter
              dhikr={s.dhikr}
              count={s.count}
              rounds={s.rounds}
              onTap={s.tap}
              onSelect={s.selectDhikr}
            />
          </div>
          <div className="fade-up" style={{ animationDelay: '0.15s' }}>
            <StatePanel
              elapsedSec={s.elapsedSec}
              running={s.running}
              total={s.total}
              onStart={s.start}
              onPause={s.pause}
              onReset={s.reset}
            />
          </div>
        </main>

        <div className="hairline-b" />

        {/* الرسم البياني */}
        <section className="fade-up py-12" style={{ animationDelay: '0.25s' }}>
          <h2 className="font-display mb-2 text-3xl text-[#fce1b6]">خريطة الرحلة والأثر</h2>
          <p className="mb-8 max-w-2xl text-sm leading-relaxed text-[--ink-dim]">
            مع كل دقيقة تسبيح متواصل يهدأ إيقاع الدماغ المتوقع. المسار الذهبي هو جلستك أنت الآن،
            والخط المتقطع يجيب عن سؤال: «لو توقفت في هذه اللحظة، كم يمتد أثر الهدوء بعدي؟»
          </p>
          <JourneyChart elapsedSec={s.elapsedSec} trace={s.trace} />
        </section>

        <div className="hairline-b" />

        {/* منهجية النموذج */}
        <section className="grid gap-10 py-12 md:grid-cols-3">
          {[
            {
              title: 'كيف يُحسب التردد؟',
              body: 'منحنى لوجستي يبدأ من يقظة بيتا (~١٩ هرتز) وينحدر تدريجياً مع استمرار التسبيح نحو ألفا (~١٠ هرتز) حول الدقيقة السادسة، ثم يستقر في ثيتا (~٥٫٥ هرتز) بعد نحو اثنتي عشرة دقيقة من المكوث المتواصل.',
            },
            {
              title: 'كيف يُحسب طول الأثر؟',
              body: 'الأثر بعد التوقف يتناسب مع عمق الحالة التي بلغتها ومدة المكوث فيها، ويتشبع عند نحو ٤٥ دقيقة. لذلك ترى المنحنى ينمو ببطء في البداية ثم يتسارع كلما اقتربت من ثيتا وطالت إقامتك فيها.',
            },
            {
              title: 'حدود هذا النموذج',
              body: 'هذا تصوّر تعليمي مستوحى من أدبيات التأمل والذكر، وليس قراءة EEG حقيقية ولا نصيحة طبية. الأجساد تختلف، والخشوع لا يُقاس بالهرتز — الغرض أن ترى لثباتك أثراً يتراكم.',
            },
          ].map((c) => (
            <div key={c.title} className="flex flex-col gap-3">
              <h3 className="font-display text-xl text-[#d4b67e]">{c.title}</h3>
              <p className="text-sm leading-loose text-[--ink-dim]">{c.body}</p>
            </div>
          ))}
        </section>

        <footer className="hairline flex items-center justify-between border-t pt-6 text-[11px] text-[--ink-faint]">
          <span>«أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ»</span>
          <span>مِسبحة — صُنعت للسكينة</span>
        </footer>
      </div>
    </div>
  )
}
