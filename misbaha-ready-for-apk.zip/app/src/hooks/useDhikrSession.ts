import { useCallback, useEffect, useRef, useState } from 'react'
import { freqAt } from '@/lib/model'

export type TracePoint = { t: number; f: number }

export type Dhikr = { id: string; text: string; target: number }

export const ADHKAR: Dhikr[] = [
  { id: 'subhan', text: 'سُبْحَانَ الله', target: 33 },
  { id: 'hamd', text: 'الْحَمْدُ لِلَّه', target: 33 },
  { id: 'akbar', text: 'اللهُ أَكْبَر', target: 34 },
  { id: 'tahlil', text: 'لَا إِلَهَ إِلَّا الله', target: 100 },
  { id: 'istighfar', text: 'أَسْتَغْفِرُ الله', target: 100 },
  { id: 'salawat', text: 'اللَّهُمَّ صَلِّ عَلَى مُحَمَّد', target: 100 },
]

export function useDhikrSession() {
  const [running, setRunning] = useState(false)
  const [elapsedSec, setElapsedSec] = useState(0) // للعرض (يُحدَّث كل 250ms)
  const [count, setCount] = useState(0)
  const [rounds, setRounds] = useState(0)
  const [total, setTotal] = useState(0)
  const [dhikrId, setDhikrId] = useState(ADHKAR[0].id)
  const [trace, setTrace] = useState<TracePoint[]>([])
  const [pulse, setPulse] = useState(0) // نبضة اللمس — تتغير عند كل تسبيحة

  const accRef = useRef(0) // ثوانٍ متراكمة قبل آخر تشغيل
  const stampRef = useRef<number | null>(null) // طابع آخر تشغيل

  const getElapsed = useCallback(() => {
    const base = accRef.current
    if (stampRef.current == null) return base
    return base + (performance.now() - stampRef.current) / 1000
  }, [])

  const start = useCallback(() => {
    if (stampRef.current != null) return
    stampRef.current = performance.now()
    setRunning(true)
  }, [])

  const pause = useCallback(() => {
    if (stampRef.current == null) return
    accRef.current = getElapsed()
    stampRef.current = null
    setRunning(false)
  }, [getElapsed])

  const reset = useCallback(() => {
    accRef.current = 0
    stampRef.current = null
    setRunning(false)
    setElapsedSec(0)
    setCount(0)
    setRounds(0)
    setTotal(0)
    setTrace([])
  }, [])

  const dhikr = ADHKAR.find((d) => d.id === dhikrId) ?? ADHKAR[0]

  const tap = useCallback(() => {
    if (stampRef.current == null) {
      stampRef.current = performance.now()
      setRunning(true)
    }
    setPulse((p) => p + 1)
    setTotal((t) => t + 1)
    setCount((c) => {
      if (c + 1 >= dhikr.target) {
        setRounds((r) => r + 1)
        return 0
      }
      return c + 1
    })
  }, [dhikr.target])

  const selectDhikr = useCallback((id: string) => {
    setDhikrId(id)
    setCount(0)
    setRounds(0)
  }, [])

  // حلقة تحديث العرض + أخذ عينات المسار
  useEffect(() => {
    const iv = window.setInterval(() => {
      const e = getElapsed()
      setElapsedSec(e)
      if (stampRef.current != null) {
        const tMin = e / 60
        setTrace((tr) => {
          const last = tr[tr.length - 1]
          if (last && Math.abs(last.t - tMin) < 1 / 240) return tr
          const next = [...tr, { t: tMin, f: freqAt(tMin) }]
          return next.length > 7200 ? next.slice(-7200) : next
        })
      }
    }, 250)
    return () => window.clearInterval(iv)
  }, [getElapsed])

  return {
    running,
    elapsedSec,
    getElapsed,
    count,
    rounds,
    total,
    dhikr,
    trace,
    pulse,
    start,
    pause,
    reset,
    tap,
    selectDhikr,
  }
}
