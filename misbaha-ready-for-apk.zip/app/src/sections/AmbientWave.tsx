import { useEffect, useRef } from 'react'
import { freqAt } from '@/lib/model'

type Props = {
  getElapsed: () => number
  pulse: number // يزيد عند كل تسبيحة
}

// تدرّج لوني حسب الحالة: مرجاني (بيتا) → ذهبي (ألفا) → فيروزي (ثيتا)
const BETA_RGB: [number, number, number] = [217, 138, 106]
const ALPHA_RGB: [number, number, number] = [212, 182, 126]
const THETA_RGB: [number, number, number] = [91, 168, 160]

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t
}

function mixColor(f: number): [number, number, number] {
  // f: 5.5..19.5 — فوق 13 بيتا، 8..13 ألفا، دونها ثيتا
  if (f >= 13) {
    const t = Math.min((f - 13) / 6.5, 1)
    return [lerp(ALPHA_RGB[0], BETA_RGB[0], t), lerp(ALPHA_RGB[1], BETA_RGB[1], t), lerp(ALPHA_RGB[2], BETA_RGB[2], t)]
  }
  const t = Math.min(Math.max((f - 5.5) / 7.5, 0), 1)
  return [lerp(THETA_RGB[0], ALPHA_RGB[0], t), lerp(THETA_RGB[1], ALPHA_RGB[1], t), lerp(THETA_RGB[2], ALPHA_RGB[2], t)]
}

/**
 * موجة محيطية حية تملأ الخلفية: سرعتها وسعتها ولونها تتبع
 * التردد الدماغي المقدَّر في كل لحظة، وتنبض مع كل تسبيحة.
 */
export default function AmbientWave({ getElapsed, pulse }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const pulseRef = useRef(0)
  const smoothFRef = useRef(19.5)

  useEffect(() => {
    pulseRef.current = Math.min(pulseRef.current + 1.4, 3)
  }, [pulse])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let raf = 0
    let w = 0
    let h = 0
    let phase = 0
    let noise = 0
    let lastNow = performance.now()

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      w = canvas.clientWidth
      h = canvas.clientHeight
      canvas.width = w * dpr
      canvas.height = h * dpr
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
    resize()
    window.addEventListener('resize', resize)

    const render = () => {
      const now = performance.now()
      const dt = Math.min((now - lastNow) / 1000, 0.1)
      lastNow = now

      const tMin = getElapsed() / 60
      const targetF = freqAt(tMin)
      // تجانس بطيء نحو التردد المستهدف
      smoothFRef.current += (targetF - smoothFRef.current) * Math.min(dt * 0.8, 1)
      const f = smoothFRef.current

      // تلاشي نبضة التسبيح
      pulseRef.current = Math.max(0, pulseRef.current - dt * 2.2)
      const pulseAmp = pulseRef.current

      // تحويل التردد إلى مؤثرات بصرية: بطيء وعميق كلما انخفض
      const depth = (19.5 - f) / (19.5 - 5.5) // 0..1
      const speed = lerp(2.4, 0.35, depth) // سرعة الطور
      const baseAmp = lerp(9, 64, depth) // سعة الموجة
      const waves = 3
      const [r, g, b] = mixColor(f)

      phase += speed * dt
      noise += (Math.random() - 0.5) * 0.22
      noise = Math.max(-3, Math.min(3, noise))

      ctx.clearRect(0, 0, w, h)

      const midY = h * 0.62
      for (let i = 0; i < waves; i++) {
        const layerAmp = baseAmp * (1 - i * 0.24) * (1 + pulseAmp * 0.55)
        const yOff = i * 26 - 26
        const alpha = 0.16 - i * 0.04 + pulseAmp * 0.05
        const k = lerp(0.028, 0.0085, depth) * (1 + i * 0.35) // كثافة التموج

        ctx.beginPath()
        for (let x = 0; x <= w; x += 3) {
          const y =
            midY +
            yOff +
            Math.sin(x * k + phase * (1 + i * 0.22)) * layerAmp +
            Math.sin(x * k * 0.37 + phase * 0.6 + i) * layerAmp * 0.4 +
            noise * (1 - i * 0.3)
          if (x === 0) ctx.moveTo(x, y)
          else ctx.lineTo(x, y)
        }
        ctx.strokeStyle = `rgba(${r | 0},${g | 0},${b | 0},${alpha})`
        ctx.lineWidth = 1.4
        ctx.stroke()
      }

      raf = requestAnimationFrame(render)
    }
    raf = requestAnimationFrame(render)

    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', resize)
    }
  }, [getElapsed])

  return (
    <canvas
      ref={canvasRef}
      className="pointer-events-none fixed inset-0 h-full w-full"
      aria-hidden
    />
  )
}
